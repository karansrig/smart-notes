@echo off
where flutter >nul 2>nul
if errorlevel 1 (
  echo Flutter SDK not found. Install Flutter and add flutter\bin to PATH.
  pause
  exit /b 1
)
flutter doctor
if errorlevel 1 exit /b 1
flutter create --platforms=android --org com.example .
if errorlevel 1 exit /b 1
flutter pub get
if errorlevel 1 exit /b 1
flutter analyze
if errorlevel 1 exit /b 1
flutter test
if errorlevel 1 exit /b 1
flutter build apk --debug
if errorlevel 1 exit /b 1
echo APK: build\app\outputs\flutter-apk\app-debug.apk
