# SmartKeep Notes

**Your thoughts. Your space. Your notes.**

Offline-first Flutter notes app using Material 3, Provider and SQLite.

## Requirements

- Flutter stable (Dart 3.4+)
- Android Studio / Android SDK
- Java 17
- Android device or emulator (Android 6.0 / API 23+)

## Build

1. Extract the ZIP.
2. Open the `smartkeep_notes` folder in Android Studio or VS Code.
3. Run `flutter doctor` and install the Android SDK components it reports missing.
4. Generate the standard Android Gradle wrapper files for your installed Flutter version (the build environment used to prepare this ZIP did not have Flutter installed):

```bash
flutter create --platforms=android --org com.example .
```

5. Run:

```bash
flutter pub get
flutter analyze
flutter test
flutter build apk --debug
```

APK output: `build/app/outputs/flutter-apk/app-debug.apk`.

## Implemented in this source package

- Local SQLite note persistence and indexed note ordering.
- Text, checklist and expense note models.
- Autosave debounce (400 ms), save on app pause and flush on back navigation.
- Pastel note colors, pinning, archive/trash data operations, restore and empty trash.
- Two-column masonry note feed, search across titles/body/checklist/expense rows/labels.
- Checklist editing and expense rows with live Indian-number currency totals.
- JSON backup export and import with transaction-based insertion.
- Light, dark and system appearance preferences.
- Seed welcome note created once.
- Basic model tests and GitHub Actions debug APK build workflow.

## Important scope and verification notes

This package is source-ready for Flutter dependency resolution, but it has **not been compiled or tested in this environment** because the Flutter and Dart SDKs are not installed here. Run the commands above on a machine with Flutter installed; the first `flutter pub get` resolves dependencies and creates/updates `pubspec.lock`.

The supplied specification also describes native home-screen widgets, individual-note encryption/locking, PIN fallback, reminders, rich text, audio/drawing/attachments, PDF/CSV exports, advanced filters, multi-select actions, and extensive integration/database tests. Those are not implemented in this initial code package and are intentionally not represented as working controls. Biometric plugin dependency is included, but the app-lock flow is not wired into the UI. No SQLCipher encryption is enabled; SQLite data is stored locally without database-level encryption.

## Data and privacy

Notes are stored in the app's private SQLite database. No account or cloud service is required. Exported JSON backups are not encrypted; store and share them accordingly.
