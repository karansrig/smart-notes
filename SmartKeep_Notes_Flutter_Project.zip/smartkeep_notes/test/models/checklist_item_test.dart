import 'package:flutter_test/flutter_test.dart';
import 'package:smartkeep_notes/models/checklist_item.dart';

void main() {
  test('checklist JSON round trip', () {
    final item = ChecklistItem(id: 'abc', text: 'Buy milk', isChecked: true);
    expect(ChecklistItem.fromJson(item.toJson()).isChecked, isTrue);
    expect(ChecklistItem.fromJson(item.toJson()).text, 'Buy milk');
  });
}
