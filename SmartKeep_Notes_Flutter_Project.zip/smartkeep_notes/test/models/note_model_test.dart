import 'package:flutter_test/flutter_test.dart';
import 'package:smartkeep_notes/models/note_model.dart';
import 'package:smartkeep_notes/models/sheet_row.dart';

void main() {
  test('expense total parses commas, decimals and negatives', () {
    const note = NoteModel(type: NoteType.expense, sheetRows: []);
    expect(note.sheetTotal, 0);
    final total = [SheetRow(id: '1', amount: '1,25,000.50'), SheetRow(id: '2', amount: '-500'), SheetRow(id: '3', amount: 'invalid')].fold<double>(0, (s, r) => s + r.numericAmount);
    expect(total, 124500.5);
  });
  test('empty note detection', () { expect(const NoteModel().isEmpty, isTrue); });
}
