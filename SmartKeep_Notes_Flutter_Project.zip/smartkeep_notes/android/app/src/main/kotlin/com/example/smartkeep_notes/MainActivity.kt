package com.example.smartkeep_notes

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
