import 'dart:convert';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../repositories/note_repository.dart';

class BackupService {
  static Future<void> export(NoteRepository repository) async {
    final data = await repository.exportData();
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/smartkeep_backup_${DateTime.now().millisecondsSinceEpoch}.json');
    await file.writeAsString(const JsonEncoder.withIndent('  ').convert(data));
    await Share.shareXFiles([XFile(file.path)], text: 'SmartKeep Notes backup');
  }
  static Future<int?> import(NoteRepository repository) async {
    final result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['json'], withData: true);
    if (result == null || result.files.single.bytes == null) return null;
    final decoded = jsonDecode(utf8.decode(result.files.single.bytes!));
    if (decoded is! Map<String, dynamic>) throw const FormatException('Invalid backup file.');
    return repository.importData(decoded);
  }
}
