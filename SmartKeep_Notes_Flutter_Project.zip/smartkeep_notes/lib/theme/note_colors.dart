import 'package:flutter/material.dart';
const noteColors = <Color>[
  Color(0xFFFFFFFF), Color(0xFFFFF8E1), Color(0xFFFFEBEE), Color(0xFFE8F5E9),
  Color(0xFFE3F2FD), Color(0xFFF3E5F5), Color(0xFFFBE9E7), Color(0xFFF1F8E9),
];
