import 'package:flutter/material.dart';

class AppTheme {
  static const blue = Color(0xFF1A73E8);
  static ThemeData light() => ThemeData(
    useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: blue, brightness: Brightness.light),
    scaffoldBackgroundColor: const Color(0xFFF8F9FC), fontFamily: 'Roboto',
    appBarTheme: const AppBarTheme(backgroundColor: Color(0xFFF8F9FC), elevation: 0, centerTitle: false),
    cardTheme: CardThemeData(color: Colors.white, elevation: 0.5, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: const BorderSide(color: Color(0xFFE8EAED)))),
    inputDecorationTheme: InputDecorationTheme(border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none), filled: true, fillColor: Colors.white),
  );
  static ThemeData dark() => ThemeData(useMaterial3: true,
    colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF8AB4F8), brightness: Brightness.dark),
    cardTheme: CardThemeData(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))));
}
