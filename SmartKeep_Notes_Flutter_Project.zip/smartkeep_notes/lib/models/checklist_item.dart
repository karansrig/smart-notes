class ChecklistItem {
  ChecklistItem({required this.id, required this.text, this.isChecked = false});
  final String id;
  final String text;
  final bool isChecked;

  ChecklistItem copyWith({String? text, bool? isChecked}) => ChecklistItem(
    id: id, text: text ?? this.text, isChecked: isChecked ?? this.isChecked);
  Map<String, dynamic> toJson() => {'id': id, 'text': text, 'isChecked': isChecked};
  factory ChecklistItem.fromJson(Map<String, dynamic> json) => ChecklistItem(
    id: json['id'] as String, text: json['text'] as String? ?? '',
    isChecked: json['isChecked'] as bool? ?? false);
}
