class SheetRow {
  SheetRow({required this.id, this.description = '', this.amount = ''});
  final String id;
  final String description;
  final String amount;
  SheetRow copyWith({String? description, String? amount}) => SheetRow(
    id: id, description: description ?? this.description, amount: amount ?? this.amount);
  double get numericAmount {
    final cleaned = amount.replaceAll(',', '').replaceAll(RegExp(r'\s'), '');
    return double.tryParse(cleaned) ?? 0;
  }
  Map<String, dynamic> toJson() => {'id': id, 'description': description, 'amount': amount};
  factory SheetRow.fromJson(Map<String, dynamic> json) => SheetRow(
    id: json['id'] as String, description: json['description'] as String? ?? '',
    amount: json['amount'] as String? ?? '');
}
