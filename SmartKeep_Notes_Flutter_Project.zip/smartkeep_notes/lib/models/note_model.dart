import 'dart:convert';
import 'checklist_item.dart';
import 'sheet_row.dart';

enum NoteType { text, checklist, expense }

class NoteModel {
  const NoteModel({this.id, this.title = '', this.content = '', this.colorHex = 0xFFFFFFFF,
    this.isPinned = false, this.isArchived = false, this.isDeleted = false,
    this.isFavorite = false, this.type = NoteType.text, this.checklist = const [],
    this.sheetRows = const [], this.labels = const [], this.createdAt = 0, this.updatedAt = 0,
    this.deletedAt});
  final int? id;
  final String title, content;
  final int colorHex;
  final bool isPinned, isArchived, isDeleted, isFavorite;
  final NoteType type;
  final List<ChecklistItem> checklist;
  final List<SheetRow> sheetRows;
  final List<String> labels;
  final int createdAt, updatedAt;
  final int? deletedAt;
  double get sheetTotal => sheetRows.fold(0, (sum, row) => sum + row.numericAmount);
  bool get isEmpty => title.trim().isEmpty && content.trim().isEmpty && checklist.isEmpty && sheetRows.isEmpty;
  NoteModel copyWith({String? title, String? content, int? colorHex, bool? isPinned,
    bool? isArchived, bool? isDeleted, bool? isFavorite, NoteType? type,
    List<ChecklistItem>? checklist, List<SheetRow>? sheetRows, List<String>? labels,
    int? updatedAt, int? deletedAt, bool clearDeletedAt = false}) => NoteModel(
      id: id, title: title ?? this.title, content: content ?? this.content,
      colorHex: colorHex ?? this.colorHex, isPinned: isPinned ?? this.isPinned,
      isArchived: isArchived ?? this.isArchived, isDeleted: isDeleted ?? this.isDeleted,
      isFavorite: isFavorite ?? this.isFavorite, type: type ?? this.type,
      checklist: checklist ?? this.checklist, sheetRows: sheetRows ?? this.sheetRows,
      labels: labels ?? this.labels, createdAt: createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      deletedAt: clearDeletedAt ? null : (deletedAt ?? this.deletedAt));
  Map<String, dynamic> toMap() => {
    'id': id, 'title': title, 'content': content, 'color_hex': colorHex,
    'is_pinned': isPinned ? 1 : 0, 'is_archived': isArchived ? 1 : 0,
    'is_deleted': isDeleted ? 1 : 0, 'is_favorite': isFavorite ? 1 : 0,
    'type': type.name, 'checklist_json': jsonEncode(checklist.map((e) => e.toJson()).toList()),
    'sheet_rows_json': jsonEncode(sheetRows.map((e) => e.toJson()).toList()),
    'labels_json': jsonEncode(labels), 'created_at': createdAt, 'updated_at': updatedAt,
    'deleted_at': deletedAt};
  factory NoteModel.fromMap(Map<String, dynamic> map) => NoteModel(
    id: map['id'] as int?, title: map['title'] as String? ?? '',
    content: map['content'] as String? ?? '', colorHex: map['color_hex'] as int? ?? 0xFFFFFFFF,
    isPinned: (map['is_pinned'] as int? ?? 0) == 1,
    isArchived: (map['is_archived'] as int? ?? 0) == 1,
    isDeleted: (map['is_deleted'] as int? ?? 0) == 1,
    isFavorite: (map['is_favorite'] as int? ?? 0) == 1,
    type: NoteType.values.firstWhere((e) => e.name == map['type'], orElse: () => NoteType.text),
    checklist: ((jsonDecode(map['checklist_json'] as String? ?? '[]') as List)
      .map((e) => ChecklistItem.fromJson(Map<String, dynamic>.from(e as Map))).toList()),
    sheetRows: ((jsonDecode(map['sheet_rows_json'] as String? ?? '[]') as List)
      .map((e) => SheetRow.fromJson(Map<String, dynamic>.from(e as Map))).toList()),
    labels: (jsonDecode(map['labels_json'] as String? ?? '[]') as List).cast<String>(),
    createdAt: map['created_at'] as int? ?? 0, updatedAt: map['updated_at'] as int? ?? 0,
    deletedAt: map['deleted_at'] as int?);
}
