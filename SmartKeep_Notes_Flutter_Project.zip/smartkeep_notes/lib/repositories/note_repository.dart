import '../core/database/app_database.dart';
import '../models/note_model.dart';

class NoteRepository {
  Future<List<NoteModel>> all({bool includeDeleted = false}) async {
    final db = await AppDatabase.instance.database;
    final rows = await db.query('notes', where: includeDeleted ? null : 'is_deleted = 0',
      orderBy: 'is_pinned DESC, updated_at DESC');
    return rows.map(NoteModel.fromMap).toList();
  }
  Future<int> save(NoteModel note) async {
    final db = await AppDatabase.instance.database;
    final now = DateTime.now().millisecondsSinceEpoch;
    final map = note.copyWith(updatedAt: now).toMap()..remove('id');
    if (note.id == null) {
      map['created_at'] = now;
      return db.insert('notes', map);
    }
    await db.update('notes', map, where: 'id = ?', whereArgs: [note.id]);
    return note.id!;
  }
  Future<void> delete(NoteModel note) async {
    final db = await AppDatabase.instance.database;
    final now = DateTime.now().millisecondsSinceEpoch;
    await db.update('notes', {'is_deleted': 1, 'deleted_at': now, 'updated_at': now},
      where: 'id = ?', whereArgs: [note.id]);
  }
  Future<void> restore(int id) async {
    final db = await AppDatabase.instance.database;
    await db.update('notes', {'is_deleted': 0, 'deleted_at': null}, where: 'id = ?', whereArgs: [id]);
  }
  Future<void> permanentlyDelete(int id) async {
    final db = await AppDatabase.instance.database;
    await db.delete('notes', where: 'id = ?', whereArgs: [id]);
  }
  Future<void> emptyTrash() async {
    final db = await AppDatabase.instance.database;
    await db.delete('notes', where: 'is_deleted = 1');
  }
  Future<List<NoteModel>> search(String query) async {
    final db = await AppDatabase.instance.database;
    final q = '%${query.trim()}%';
    final rows = await db.rawQuery('''SELECT * FROM notes WHERE is_deleted = 0 AND
      (title LIKE ? COLLATE NOCASE OR content LIKE ? COLLATE NOCASE OR
       checklist_json LIKE ? COLLATE NOCASE OR sheet_rows_json LIKE ? COLLATE NOCASE OR labels_json LIKE ? COLLATE NOCASE)
      ORDER BY is_pinned DESC, updated_at DESC''', [q,q,q,q,q]);
    return rows.map(NoteModel.fromMap).toList();
  }
  Future<void> seedWelcome() async {
    final db = await AppDatabase.instance.database;
    final found = await db.query('notes', where: 'title = ?', whereArgs: ['Welcome to SmartKeep Notes'], limit: 1);
    if (found.isNotEmpty) return;
    final now = DateTime.now().millisecondsSinceEpoch;
    await save(NoteModel(title: 'Welcome to SmartKeep Notes', content: 'Your thoughts. Your space. Your notes.\n\nEverything stays on this device.', colorHex: 0xFFFFF8E1,
      type: NoteType.text, createdAt: now, updatedAt: now));
  }
  Future<Map<String, dynamic>> exportData() async => {
    'format': 'smartkeep-backup', 'version': 1, 'exportedAt': DateTime.now().toIso8601String(),
    'notes': (await all(includeDeleted: true)).map((n) => n.toMap()).toList()};
  Future<int> importData(Map<String, dynamic> backup) async {
    if (backup['format'] != 'smartkeep-backup' || backup['notes'] is! List) {
      throw const FormatException('This is not a valid SmartKeep backup.');
    }
    final db = await AppDatabase.instance.database;
    var count = 0;
    await db.transaction((txn) async {
      for (final raw in backup['notes'] as List) {
        final map = Map<String, dynamic>.from(raw as Map)..remove('id');
        map['created_at'] = map['created_at'] ?? DateTime.now().millisecondsSinceEpoch;
        map['updated_at'] = map['updated_at'] ?? DateTime.now().millisecondsSinceEpoch;
        await txn.insert('notes', map);
        count++;
      }
    });
    return count;
  }
}
