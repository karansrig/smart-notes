import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

class AppDatabase {
  AppDatabase._();
  static final AppDatabase instance = AppDatabase._();
  Database? _database;
  Future<Database> get database async => _database ??= await _open();
  Future<Database> _open() async {
    final root = await getDatabasesPath();
    return openDatabase(p.join(root, 'smartkeep_notes.db'), version: 1,
      onCreate: (db, version) async {
        await db.execute('''CREATE TABLE notes (
          id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL DEFAULT '',
          content TEXT NOT NULL DEFAULT '', color_hex INTEGER NOT NULL,
          is_pinned INTEGER NOT NULL DEFAULT 0, is_archived INTEGER NOT NULL DEFAULT 0,
          is_deleted INTEGER NOT NULL DEFAULT 0, is_favorite INTEGER NOT NULL DEFAULT 0,
          type TEXT NOT NULL, checklist_json TEXT NOT NULL DEFAULT '[]',
          sheet_rows_json TEXT NOT NULL DEFAULT '[]', labels_json TEXT NOT NULL DEFAULT '[]',
          created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL, deleted_at INTEGER)''');
        await db.execute('CREATE INDEX idx_notes_order ON notes(is_deleted, is_archived, is_pinned DESC, updated_at DESC)');
        await db.execute('CREATE INDEX idx_notes_updated ON notes(updated_at DESC)');
      },
      onUpgrade: (db, oldVersion, newVersion) async {
        // Add versioned migrations here when the schema evolves.
      });
  }
}
