import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'features/home/home_screen.dart';
import 'providers/note_provider.dart';
import 'providers/settings_provider.dart';
import 'theme/app_theme.dart';

class SmartKeepApp extends StatelessWidget {
  const SmartKeepApp({super.key});
  @override Widget build(BuildContext context) => Consumer<SettingsProvider>(builder: (_, settings, __) => MaterialApp(
    title: 'SmartKeep Notes', debugShowCheckedModeBanner: false,
    theme: AppTheme.light(), darkTheme: AppTheme.dark(), themeMode: settings.themeMode,
    home: const HomeScreen()));
}
