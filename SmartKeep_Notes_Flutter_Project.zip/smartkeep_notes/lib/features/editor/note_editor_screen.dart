import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';
import '../../models/checklist_item.dart';
import '../../models/note_model.dart';
import '../../models/sheet_row.dart';
import '../../providers/note_provider.dart';
import '../../theme/note_colors.dart';
import '../../widgets/currency_text.dart';

class NoteEditorScreen extends StatefulWidget {
  const NoteEditorScreen({super.key, this.note, this.initialType = NoteType.text});
  final NoteModel? note;
  final NoteType initialType;
  @override State<NoteEditorScreen> createState() => _NoteEditorScreenState();
}
class _NoteEditorScreenState extends State<NoteEditorScreen> with WidgetsBindingObserver {
  late final TextEditingController title;
  late final TextEditingController content;
  late NoteType type;
  late int color;
  late bool pinned;
  late List<ChecklistItem> items;
  late List<SheetRow> rows;
  int? noteId;
  Timer? debounce;
  bool saving = false;
  bool dirty = false;
  final uuid = const Uuid();
  @override void initState() {
    super.initState(); WidgetsBinding.instance.addObserver(this);
    final n = widget.note;
    title = TextEditingController(text: n?.title ?? '');
    content = TextEditingController(text: n?.content ?? '');
    type = n?.type ?? widget.initialType; color = n?.colorHex ?? noteColors.first.toARGB32();
    pinned = n?.isPinned ?? false; items = List.of(n?.checklist ?? []); rows = List.of(n?.sheetRows ?? []); noteId = n?.id;
    title.addListener(scheduleSave); content.addListener(scheduleSave);
    if (type == NoteType.checklist && items.isEmpty) items.add(ChecklistItem(id: uuid.v4(), text: ''));
    if (type == NoteType.expense && rows.isEmpty) rows.add(SheetRow(id: uuid.v4()));
  }
  @override void dispose() { WidgetsBinding.instance.removeObserver(this); debounce?.cancel(); title.dispose(); content.dispose(); super.dispose(); }
  @override void didChangeAppLifecycleState(AppLifecycleState state) { if (state == AppLifecycleState.paused || state == AppLifecycleState.inactive) flushSave(); }
  void scheduleSave() { dirty = true; debounce?.cancel(); debounce = Timer(const Duration(milliseconds: 400), flushSave); }
  Future<void> flushSave() async {
    debounce?.cancel(); if (!dirty || !mounted) return;
    dirty = false; setState(() => saving = true);
    final old = widget.note;
    final model = NoteModel(id: noteId, title: title.text, content: content.text, colorHex: color,
      isPinned: pinned, isArchived: old?.isArchived ?? false, isDeleted: old?.isDeleted ?? false,
      isFavorite: old?.isFavorite ?? false, type: type, checklist: List.of(items), sheetRows: List.of(rows),
      labels: old?.labels ?? [], createdAt: old?.createdAt ?? DateTime.now().millisecondsSinceEpoch,
      updatedAt: DateTime.now().millisecondsSinceEpoch);
    try { noteId = await context.read<NoteProvider>().save(model); }
    catch (_) { dirty = true; }
    if (mounted) setState(() => saving = false);
  }
  void changed() { scheduleSave(); setState(() {}); }
  Future<void> chooseColor() async {
    await showModalBottomSheet<void>(context: context, showDragHandle: true, builder: (ctx) => Padding(
      padding: const EdgeInsets.all(20), child: Wrap(spacing: 18, runSpacing: 18, children: noteColors.map((c) => InkWell(
        onTap: () { setState(() => color = c.toARGB32()); scheduleSave(); Navigator.pop(ctx); },
        child: CircleAvatar(radius: 23, backgroundColor: c, child: color == c.toARGB32() ? const Icon(Icons.check, color: Colors.black54) : null))).toList())));
  }
  @override Widget build(BuildContext context) {
    final bg = Color(color);
    return PopScope(canPop: false, onPopInvokedWithResult: (didPop, result) async { if (!didPop) { await flushSave(); if (mounted) Navigator.pop(context); } },
      child: Scaffold(backgroundColor: bg, appBar: AppBar(backgroundColor: bg,
        leading: IconButton(icon: const Icon(Icons.arrow_back), onPressed: () async { await flushSave(); if (mounted) Navigator.pop(context); }),
        title: Text(saving ? 'Saving…' : (dirty ? 'Unsaved changes' : 'Saved'), style: Theme.of(context).textTheme.labelSmall),
        actions: [IconButton(tooltip: pinned ? 'Unpin' : 'Pin', onPressed: () { pinned = !pinned; changed(); }, icon: Icon(pinned ? Icons.push_pin : Icons.push_pin_outlined)),
          IconButton(tooltip: 'Note color', onPressed: chooseColor, icon: const Icon(Icons.palette_outlined)),
          PopupMenuButton<String>(onSelected: (v) async { if (v == 'delete') { await flushSave(); final n = widget.note; if (n != null) await context.read<NoteProvider>().trashNote(n); if (mounted) Navigator.pop(context); } }, itemBuilder: (_) => const [PopupMenuItem(value: 'delete', child: Text('Move to trash'))])]),
        body: SafeArea(child: ListView(padding: const EdgeInsets.fromLTRB(20, 8, 20, 32), children: [
          TextField(controller: title, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w600), decoration: const InputDecoration(hintText: 'Title', filled: false, border: InputBorder.none)),
          const SizedBox(height: 8),
          if (type == NoteType.text) TextField(controller: content, minLines: 12, maxLines: null, keyboardType: TextInputType.multiline, style: const TextStyle(fontSize: 16, height: 1.5), decoration: const InputDecoration(hintText: 'Start writing…', filled: false, border: InputBorder.none)),
          if (type == NoteType.checklist) _checklistEditor(),
          if (type == NoteType.expense) _expenseEditor(),
        ]))));
  }
  Widget _checklistEditor() => Column(children: [Row(children: [Text('CHECKLIST  ${items.where((e) => e.isChecked).length}/${items.length}', style: const TextStyle(fontWeight: FontWeight.w700, letterSpacing: 1)), const Spacer(), TextButton.icon(onPressed: () { items.add(ChecklistItem(id: uuid.v4(), text: '')); changed(); }, icon: const Icon(Icons.add), label: const Text('Add item'))]),
    ...items.asMap().entries.map((entry) { final i = entry.key, item = entry.value; return Row(key: ValueKey(item.id), children: [Checkbox(value: item.isChecked, onChanged: (v) { items[i] = item.copyWith(isChecked: v); changed(); }), Expanded(child: TextFormField(initialValue: item.text, onChanged: (v) { items[i] = item.copyWith(text: v); scheduleSave(); }, decoration: const InputDecoration(hintText: 'List item', border: InputBorder.none), style: TextStyle(decoration: item.isChecked ? TextDecoration.lineThrough : null, color: item.isChecked ? Colors.grey : null))), IconButton(onPressed: () { if (i > 0) { final a = items[i-1]; items[i-1] = item; items[i] = a; changed(); } }, icon: const Icon(Icons.keyboard_arrow_up)), IconButton(onPressed: () { items.removeAt(i); changed(); }, icon: const Icon(Icons.close, size: 19))]); })]);
  Widget _expenseEditor() => Card(color: Colors.white, child: Padding(padding: const EdgeInsets.all(14), child: Column(children: [Row(children: [const Expanded(child: Text('MINI SPREADSHEET', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1))), TextButton.icon(onPressed: () { rows.add(SheetRow(id: uuid.v4())); changed(); }, icon: const Icon(Icons.add), label: const Text('Add row'))]), const Row(children: [Expanded(flex: 3, child: Text('Description', style: TextStyle(color: Colors.grey))), Expanded(child: Text('Amount (₹)', style: TextStyle(color: Colors.grey)))]), const Divider(),
    ...rows.asMap().entries.map((entry) { final i = entry.key, row = entry.value; return Row(key: ValueKey(row.id), children: [Expanded(flex: 3, child: TextFormField(initialValue: row.description, onChanged: (v) { rows[i] = row.copyWith(description: v); scheduleSave(); setState(() {}); }, decoration: const InputDecoration(hintText: 'Item', border: InputBorder.none))), Expanded(child: TextFormField(initialValue: row.amount, keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true), inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9,.\- ]'))], onChanged: (v) { rows[i] = row.copyWith(amount: v); scheduleSave(); setState(() {}); }, decoration: const InputDecoration(hintText: '0.00', border: InputBorder.none))), IconButton(onPressed: () { rows.removeAt(i); changed(); }, icon: const Icon(Icons.delete_outline, size: 19))]); }),
    Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: const Color(0xFFE6F4EA), borderRadius: BorderRadius.circular(12)), child: Row(children: [Expanded(child: Text('TOTAL SUM (${rows.length} ITEMS)', style: const TextStyle(color: Color(0xFF137333), fontWeight: FontWeight.bold))), Text(CurrencyText.format(rows.fold<double>(0, (s, r) => s + r.numericAmount)), style: const TextStyle(color: Color(0xFF137333), fontWeight: FontWeight.bold, fontSize: 18))]))])));
}
