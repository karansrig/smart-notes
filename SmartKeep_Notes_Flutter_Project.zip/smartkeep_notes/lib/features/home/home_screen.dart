import 'package:flutter/material.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import 'package:provider/provider.dart';
import '../../models/note_model.dart';
import '../../providers/note_provider.dart';
import '../../providers/settings_provider.dart';
import '../../repositories/note_repository.dart';
import '../../services/backup_service.dart';
import '../../widgets/note_card.dart';
import '../editor/note_editor_screen.dart';

class HomeScreen extends StatefulWidget { const HomeScreen({super.key}); @override State<HomeScreen> createState() => _HomeScreenState(); }
class _HomeScreenState extends State<HomeScreen> {
  int tab = 0; String query = '';
  @override Widget build(BuildContext context) {
    final provider = context.watch<NoteProvider>();
    return Scaffold(body: SafeArea(child: Column(children: [
      Padding(padding: const EdgeInsets.fromLTRB(20, 14, 16, 10), child: Row(children: [const Icon(Icons.sticky_note_2_rounded, color: Color(0xFF1A73E8), size: 28), const SizedBox(width: 10), const Expanded(child: Text('SmartKeep Notes', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700))), IconButton(onPressed: () => setState(() => tab = 3), icon: const Icon(Icons.settings_outlined))])),
      if (tab == 0 || tab == 1) Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: TextField(onChanged: (v) => setState(() => query = v), decoration: InputDecoration(hintText: 'Search your notes', prefixIcon: const Icon(Icons.search), suffixIcon: query.isEmpty ? null : IconButton(onPressed: () => setState(() => query = ''), icon: const Icon(Icons.close)), filled: true, fillColor: Theme.of(context).colorScheme.surface, border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none)))),
      Expanded(child: _body(provider)),
    ])),
      floatingActionButton: tab == 0 ? FloatingActionButton(backgroundColor: const Color(0xFF1A73E8), foregroundColor: Colors.white, onPressed: _createMenu, child: const Icon(Icons.add, size: 28)) : null,
      bottomNavigationBar: NavigationBar(selectedIndex: tab, onDestinationSelected: (v) => setState(() { tab = v; query = ''; }), destinations: const [NavigationDestination(icon: Icon(Icons.lightbulb_outline), selectedIcon: Icon(Icons.lightbulb), label: 'Notes'), NavigationDestination(icon: Icon(Icons.search), label: 'Search'), NavigationDestination(icon: Icon(Icons.label_outline), label: 'Labels'), NavigationDestination(icon: Icon(Icons.settings_outlined), label: 'Settings')]),
    );
  }
  Widget _body(NoteProvider p) {
    if (p.loading) return const Center(child: CircularProgressIndicator());
    if (p.error.isNotEmpty) return Center(child: Text(p.error));
    if (tab == 3) return _settings();
    if (tab == 2) return _labels(p);
    if (tab == 1) return _search(p);
    final notes = p.active.where((n) => query.isEmpty || _matches(n, query)).toList();
    if (notes.isEmpty) return _empty();
    final pinned = notes.where((n) => n.isPinned).toList(), others = notes.where((n) => !n.isPinned).toList();
    return RefreshIndicator(onRefresh: p.load, child: ListView(padding: const EdgeInsets.fromLTRB(12, 14, 12, 90), children: [
      if (pinned.isNotEmpty) ...[_section('PINNED'), _grid(pinned)],
      if (others.isNotEmpty) ...[_section(pinned.isEmpty ? 'NOTES' : 'OTHERS'), _grid(others)],
      if (p.archived.isNotEmpty) TextButton.icon(onPressed: () => _showCollection('Archived', p.archived), icon: const Icon(Icons.archive_outlined), label: Text('Archived (${p.archived.length})')),
      if (p.trash.isNotEmpty) TextButton.icon(onPressed: () => _showTrash(p), icon: const Icon(Icons.delete_outline), label: Text('Trash (${p.trash.length})')),
    ]));
  }
  bool _matches(NoteModel n, String q) => '${n.title} ${n.content} ${n.labels} ${n.checklist.map((e) => e.text).join(' ')} ${n.sheetRows.map((e) => '${e.description} ${e.amount}').join(' ')}'.toLowerCase().contains(q.toLowerCase());
  Widget _section(String s) => Padding(padding: const EdgeInsets.fromLTRB(8, 10, 8, 8), child: Text(s, style: const TextStyle(fontSize: 11, letterSpacing: 1.2, fontWeight: FontWeight.w700, color: Color(0xFF5F6368))));
  Widget _grid(List<NoteModel> notes) => MasonryGridView.count(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisCount: 2, mainAxisSpacing: 10, crossAxisSpacing: 10, itemCount: notes.length, itemBuilder: (_, i) => NoteCard(note: notes[i], onTap: () => _edit(notes[i]), onPin: () => context.read<NoteProvider>().togglePin(notes[i])));
  Widget _empty() => Center(child: Padding(padding: const EdgeInsets.all(32), child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.sticky_note_2_outlined, size: 58, color: Colors.blueGrey.shade200), const SizedBox(height: 16), const Text('Your space for ideas', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w600)), const SizedBox(height: 6), const Text('Create your first note to get started.', style: TextStyle(color: Colors.grey))])));
  Widget _search(NoteProvider p) => FutureBuilder<List<NoteModel>>(future: query.trim().isEmpty ? Future.value([]) : p.search(query), builder: (_, snap) { final list = snap.data ?? []; if (query.isEmpty) return const Center(child: Text('Search your notes')); if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator()); return list.isEmpty ? _empty() : ListView(padding: const EdgeInsets.all(12), children: [_grid(list)]); });
  Widget _labels(NoteProvider p) { final labels = p.active.expand((n) => n.labels).toSet().toList()..sort(); return labels.isEmpty ? const Center(child: Text('Labels you add to notes will appear here.')) : ListView(children: labels.map((l) => ListTile(leading: const Icon(Icons.label_outline), title: Text(l), trailing: Text('${p.active.where((n) => n.labels.contains(l)).length}'), onTap: () => _showCollection(l, p.active.where((n) => n.labels.contains(l)).toList())).toList()); }
  Widget _settings() => ListView(padding: const EdgeInsets.all(20), children: [const Text('Settings', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w700)), const SizedBox(height: 18), const Text('APPEARANCE', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.grey)), const SizedBox(height: 8), Consumer<SettingsProvider>(builder: (_, s, __) => SegmentedButton<ThemeMode>(segments: const [ButtonSegment(value: ThemeMode.system, label: Text('System')), ButtonSegment(value: ThemeMode.light, label: Text('Light')), ButtonSegment(value: ThemeMode.dark, label: Text('Dark'))], selected: {s.themeMode}, onSelectionChanged: (v) => s.setTheme(v.first))), const SizedBox(height: 24), const Text('DATA', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.grey)), ListTile(leading: const Icon(Icons.upload_file), title: const Text('Export backup'), subtitle: const Text('Save all notes as JSON'), onTap: () => BackupService.export(context.read<NoteProvider>().repository)), ListTile(leading: const Icon(Icons.download), title: const Text('Import backup'), onTap: () async { final count = await BackupService.import(context.read<NoteProvider>().repository); await context.read<NoteProvider>().load(); if (mounted && count != null) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Imported $count notes'))); }), const Divider(), const ListTile(leading: Icon(Icons.lock_outline), title: Text('Biometric app lock'), subtitle: Text('Available through Android biometric APIs; enable in a future settings update')), const ListTile(leading: Icon(Icons.info_outline), title: Text('SmartKeep Notes'), subtitle: Text('Version 1.0.0 · Offline-first personal notes'))]);
  Future<void> _createMenu() async { final choice = await showModalBottomSheet<NoteType>(context: context, showDragHandle: true, builder: (_) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [ListTile(leading: const Icon(Icons.notes), title: const Text('New text note'), onTap: () => Navigator.pop(context, NoteType.text)), ListTile(leading: const Icon(Icons.checklist), title: const Text('New checklist'), onTap: () => Navigator.pop(context, NoteType.checklist)), ListTile(leading: const Icon(Icons.table_chart_outlined), title: const Text('New expense sheet'), onTap: () => Navigator.pop(context, NoteType.expense)), const SizedBox(height: 10)]))); if (choice != null && mounted) _edit(null, type: choice); }
  void _edit(NoteModel? note, {NoteType type = NoteType.text}) => Navigator.push(context, MaterialPageRoute(builder: (_) => NoteEditorScreen(note: note, initialType: type)));
  void _showCollection(String title, List<NoteModel> list) => showModalBottomSheet<void>(context: context, isScrollControlled: true, builder: (_) => SafeArea(child: SizedBox(height: 500, child: Column(children: [Padding(padding: const EdgeInsets.all(16), child: Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold))), Expanded(child: ListView(children: list.map((n) => ListTile(title: Text(n.title.isEmpty ? 'Untitled' : n.title), subtitle: Text(n.content, maxLines: 1, overflow: TextOverflow.ellipsis), onTap: () { Navigator.pop(context); _edit(n); })).toList()))]))));
  void _showTrash(NoteProvider p) => showModalBottomSheet<void>(context: context, isScrollControlled: true, builder: (_) => SafeArea(child: SizedBox(height: 500, child: Column(children: [Padding(padding: const EdgeInsets.all(16), child: Row(children: [const Expanded(child: Text('Trash', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))), TextButton(onPressed: () async { await p.emptyTrash(); if (mounted) Navigator.pop(context); }, child: const Text('Empty'))])), Expanded(child: ListView(children: p.trash.map((n) => ListTile(title: Text(n.title.isEmpty ? 'Untitled' : n.title), trailing: IconButton(icon: const Icon(Icons.restore), onPressed: () => p.restore(n.id!))).toList()))]))));
}
