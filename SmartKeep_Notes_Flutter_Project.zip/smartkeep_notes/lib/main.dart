import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'app.dart';
import 'providers/note_provider.dart';
import 'providers/settings_provider.dart';
import 'repositories/note_repository.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final repository = NoteRepository();
  await repository.seedWelcome();
  final notes = NoteProvider(repository);
  await notes.load();
  final settings = SettingsProvider();
  await settings.load();
  runApp(MultiProvider(providers: [ChangeNotifierProvider.value(value: notes), ChangeNotifierProvider.value(value: settings)], child: const SmartKeepApp()));
}
