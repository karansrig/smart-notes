import 'package:intl/intl.dart';
class CurrencyText {
  static final _format = NumberFormat.currency(locale: 'en_IN', symbol: '₹', decimalDigits: 2);
  static String format(num value) => _format.format(value);
}
