import 'package:flutter/material.dart';
import '../models/note_model.dart';
import '../widgets/currency_text.dart';

class NoteCard extends StatelessWidget {
  const NoteCard({super.key, required this.note, required this.onTap, required this.onPin});
  final NoteModel note; final VoidCallback onTap, onPin;
  @override Widget build(BuildContext context) => Card(
    color: Color(note.colorHex), clipBehavior: Clip.antiAlias,
    child: InkWell(onTap: onTap, onLongPress: onPin, child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [Expanded(child: Text(note.title.isEmpty ? 'Untitled' : note.title, maxLines: 3, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600))), IconButton(visualDensity: VisualDensity.compact, padding: EdgeInsets.zero, constraints: const BoxConstraints(), onPressed: onPin, icon: Icon(note.isPinned ? Icons.push_pin : Icons.push_pin_outlined, size: 17, color: Colors.black54))]),
      if (note.content.trim().isNotEmpty) Padding(padding: const EdgeInsets.only(top: 7), child: Text(note.content, maxLines: 5, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13, height: 1.4, color: Color(0xFF454545)))),
      if (note.type == NoteType.checklist) ...note.checklist.take(4).map((item) => Padding(padding: const EdgeInsets.only(top: 5), child: Row(children: [Icon(item.isChecked ? Icons.check_box : Icons.check_box_outline_blank, size: 16, color: Colors.black54), const SizedBox(width: 6), Expanded(child: Text(item.text, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12, decoration: item.isChecked ? TextDecoration.lineThrough : null, color: item.isChecked ? Colors.grey : Colors.black87)))])),
      if (note.type == NoteType.expense) Padding(padding: const EdgeInsets.only(top: 8), child: Text('${note.sheetRows.length} rows  |  ∑ ${CurrencyText.format(note.sheetTotal)}', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600))),
      if (note.labels.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: Wrap(spacing: 4, children: note.labels.take(3).map((l) => Chip(label: Text(l, style: const TextStyle(fontSize: 10)), visualDensity: VisualDensity.compact, padding: EdgeInsets.zero)).toList())),
      const SizedBox(height: 8), Text(_date(note.updatedAt), style: const TextStyle(fontSize: 10, color: Colors.black54)),
    ]))));
  String _date(int ms) { if (ms == 0) return ''; final d = DateTime.fromMillisecondsSinceEpoch(ms); return '${d.day}/${d.month}/${d.year}'; }
}
