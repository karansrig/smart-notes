import 'dart:async';
import 'package:flutter/foundation.dart';
import '../models/note_model.dart';
import '../repositories/note_repository.dart';

class NoteProvider extends ChangeNotifier {
  NoteProvider(this.repository);
  final NoteRepository repository;
  List<NoteModel> notes = [];
  bool loading = true;
  String error = '';
  Future<void> load() async {
    loading = true; notifyListeners();
    try { notes = await repository.all(); error = ''; }
    catch (e) { error = 'Could not load notes: $e'; }
    loading = false; notifyListeners();
  }
  List<NoteModel> get active => notes.where((n) => !n.isDeleted && !n.isArchived).toList();
  List<NoteModel> get pinned => active.where((n) => n.isPinned).toList();
  List<NoteModel> get others => active.where((n) => !n.isPinned).toList();
  List<NoteModel> get archived => notes.where((n) => n.isArchived && !n.isDeleted).toList();
  List<NoteModel> get trash => notes.where((n) => n.isDeleted).toList();
  Future<int> save(NoteModel note) async { final id = await repository.save(note); await load(); return id; }
  Future<void> trashNote(NoteModel note) async { await repository.delete(note); await load(); }
  Future<void> restore(int id) async { await repository.restore(id); await load(); }
  Future<void> permanentlyDelete(int id) async { await repository.permanentlyDelete(id); await load(); }
  Future<void> emptyTrash() async { await repository.emptyTrash(); await load(); }
  Future<List<NoteModel>> search(String q) => repository.search(q);
  Future<void> togglePin(NoteModel note) async => save(note.copyWith(isPinned: !note.isPinned));
  Future<void> toggleArchive(NoteModel note) async => save(note.copyWith(isArchived: !note.isArchived));
}
