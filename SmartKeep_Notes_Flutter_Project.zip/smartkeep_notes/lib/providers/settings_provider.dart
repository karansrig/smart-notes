import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SettingsProvider extends ChangeNotifier {
  ThemeMode themeMode = ThemeMode.system;
  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    themeMode = ThemeMode.values.firstWhere((e) => e.name == (prefs.getString('theme_mode') ?? 'system'), orElse: () => ThemeMode.system);
    notifyListeners();
  }
  Future<void> setTheme(ThemeMode value) async {
    themeMode = value; final prefs = await SharedPreferences.getInstance();
    await prefs.setString('theme_mode', value.name); notifyListeners();
  }
}
