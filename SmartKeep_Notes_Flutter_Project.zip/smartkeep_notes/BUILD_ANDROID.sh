#!/usr/bin/env bash
set -euo pipefail
command -v flutter >/dev/null || { echo 'Install Flutter and add it to PATH.'; exit 1; }
flutter doctor
flutter create --platforms=android --org com.example .
flutter pub get
flutter analyze
flutter test
flutter build apk --debug
echo 'APK: build/app/outputs/flutter-apk/app-debug.apk'
